---------------------------------
Using MAKE
make
---------------------------------


---------------------------------
Using CMAKE
Using a separate build directory:

cd build
cmake -DCMAKE_INSTALL_PREFIX=../../../.. ..
make
---------------------------------
