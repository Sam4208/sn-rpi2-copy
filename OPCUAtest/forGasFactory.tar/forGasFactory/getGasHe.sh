#!/bin/bash
    echo "25.4"

