
#ifndef _JSON_FORMAT
#define _JSON_FORMAT 1

void JSON_PrintAccel(struct accelReport* ptr);
int JSON_SnprintfAdc(char* outString, int len, adcDataReport* ptr);
void JSON_PrintAdc(adcDataReport* ptr);

#endif
