#!/bin/bash
    echo "cmd=$1"

